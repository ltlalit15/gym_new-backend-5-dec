import { pool } from "../../config/db.js";

export const createTaskService = async (data) => {
  const {
    assignedTo,
    branchId,
    taskTitle,
    dueDate,
    priority,
    description,
    createdById,
  } = data;

  const [result] = await pool.query(
    `INSERT INTO tasks (assignedTo, branchId, taskTitle, dueDate, priority, description, status, createdById)
     VALUES (?, ?, ?, ?, ?, ?,'Pending', ?)`,
    [
      assignedTo,
      branchId,
      taskTitle,
      dueDate,
      priority,
      description,
      createdById,
    ]
  );

  const [rows] = await pool.query(`SELECT * FROM tasks WHERE id = ?`, [
    result.insertId,
  ]);

  return rows[0];
};

export const getAllTasksService = async () => {
  const [rows] = await pool.query(`SELECT * FROM tasks ORDER BY id DESC`);
  return rows;
};

 export const getTaskByBranchIdService=async(branchId)=>{
  const [rows]=await pool.query(`SELECT * FROM tasks WHERE branchId=? ORDER BY id DESC`,[branchId]);
  return rows;
 }

 export const getTaskAsignedService=async(assignedTo)=>{
  const [rows]=await pool.query(`SELECT * FROM tasks WHERE assignedTo=? ORDER BY id DESC`,[assignedTo]);
  return rows;
 }
export const getTaskByIdService = async (id) => {
  const [rows] = await pool.query(`SELECT * FROM tasks WHERE id = ?`, [id]);
  return rows[0];
};

export const updateTaskService = async (id, data) => {
  // 1️⃣ Pahle old task fetch karo
  const [existing] = await pool.query(`SELECT * FROM tasks WHERE id = ?`, [id]);

  if (!existing.length) {
    throw { status: 404, message: "Task not found" };
  }

  const old = existing[0];

  // 2️⃣ New data ko merge karo → undefined fields old values le lenge
  const updatedData = {
    assignedTo: data.assignedTo ?? old.assignedTo,
    branchId: data.branchId ?? old.branchId,
    taskTitle: data.taskTitle ?? old.taskTitle,
    dueDate: data.dueDate ?? old.dueDate,
    priority: data.priority ?? old.priority,
    description: data.description ?? old.description,
    status: data.status ?? old.status,
  };

  // 3️⃣ Now update final merged data
  await pool.query(
    `UPDATE tasks SET 
      assignedTo = ?, 
      branchId = ?, 
      taskTitle = ?, 
      dueDate = ?, 
      priority = ?, 
      description = ?, 
      status = ?
     WHERE id = ?`,
    [
      updatedData.assignedTo,
      updatedData.branchId,
      updatedData.taskTitle,
      updatedData.dueDate,
      updatedData.priority,
      updatedData.description,
      updatedData.status,
      id
    ]
  );

  // 4️⃣ Updated data return karo
  const [rows] = await pool.query(`SELECT * FROM tasks WHERE id = ?`, [id]);
  return rows[0];
};


export const updateTaskStatusService = async (id, status) => {
  await pool.query(`UPDATE tasks SET status = ? WHERE id = ?`, [status, id]);

  const [rows] = await pool.query(`SELECT * FROM tasks WHERE id = ?`, [id]);
  return rows[0];
};

export const deleteTaskService = async (id) => {
  await pool.query(`DELETE FROM tasks WHERE id = ?`, [id]);
  return { message: "Task deleted successfully" };
};
